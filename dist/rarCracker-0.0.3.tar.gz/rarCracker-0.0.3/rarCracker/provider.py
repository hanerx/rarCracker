class Provider:
    def __init__(self):
        pass

    def generate(self, file) -> iter:
        pass
