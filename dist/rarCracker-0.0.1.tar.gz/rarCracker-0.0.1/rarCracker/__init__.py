name = 'rarCracker'

from rarCracker.main import RarCracker
